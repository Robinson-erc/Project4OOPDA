
/**
 * Write a description of class Duck here.
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public class Duck extends Animal
{
   boolean LeafAndStick;

    public Duck(double weight, String name)
    {
        super(weight, name);
        
        RandomInteger r1 = new RandomInteger(1, 10);
        int num = r1.Generate();
        LeafAndStick = (num > 8) ? true : false;
        
    }

    /**
     * Sound - Concrete implementation
     *
     * @parm - none
     * @return - void
     */
    @Override
    public void Sound()
    {
        System.out.println("Quuuuaaaaaaak!, Quuuuuuuaaaaaaaaaak!! ");
    }

    /**
     * Eat - Concrete implementation
     *
     * @param  - none
     * @return - void
     */
    @Override
    public void Eat()
    {
        System.out.println("Eating bread crumbs from kind strangers yum!!!!!!!");
    }

    /**
     * Happy - Concrete implementation
     *
     * @param  - none
     * @return - boolean
     */
    @Override
    public boolean Happy()
    {
        return (!LeafAndStick);
    }
}
