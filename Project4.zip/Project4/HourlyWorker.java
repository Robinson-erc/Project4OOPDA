
/**
 * Write a description of class HourlyWorker here.
 *
  * @author (Eric Robinson)
 * @version (4/12/23) */
public class HourlyWorker extends Person
{
    private double PayRate;
    private int Hours;
    public HourlyWorker(){
        super();
        PayRate=0.0;
        Hours=0;
    }

    public HourlyWorker(int id, String LastName, int Hours, double PayRate){
        super(id, LastName);
        this.PayRate=PayRate;
        this.Hours=Hours;
    }

    public double GetPayRate(){
        return this.PayRate;
    }

    public double GetHours(){
        return this.Hours;
    }

    public void SetPayRate(double PayRate){
        this.PayRate=PayRate;
    }

    public void SetHours(double Hours){
        this.PayRate=PayRate;
    }

    @Override
    public double ComputeSalary(){
        double OverSalary=0.0;
        double NetTime=0.0;
        if(Hours>40){
            double OverTime=Hours-40;
            NetTime=(Hours-OverTime); 
            OverSalary = OverTime*1.5;
        }

        return PayRate*NetTime+OverSalary;
    }

    @Override
    public String toString()
    {
        return (super.toString() + " " + this.ComputeSalary());
    }

}
