
/**
 * Write a description of class Dragon here.
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public class Dragon extends Animal
{
    boolean Fireball;

    public Dragon(double weight, String name)
    {
        super(weight, name);
        
        RandomInteger r1 = new RandomInteger(1, 10);
        int num = r1.Generate();
        Fireball = (num > 8) ? true : false;
        
    }

    /**
     * Sound - Concrete implementation
     *
     * @parm - none
     * @return - void
     */
    @Override
    public void Sound()
    {
        System.out.println("Rawrrrrrrrr!, Hgggghhhhhreeeeeeee!!, Raaaaaaaawrrrrrrrr!!!!!! ");
    }

    /**
     * Eat - Concrete implementation
     *
     * @param  - none
     * @return - void
     */
    @Override
    public void Eat()
    {
        System.out.println("Eating Villagers!!!!!!!");
    }

    /**
     * Happy - Concrete implementation
     *
     * @param  - none
     * @return - boolean
     */
    @Override
    public boolean Happy()
    {
        return (!Fireball);
    }
}
