
/**
 * Write a description of class Intern here.
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public class Intern extends Person
{
    private double WeeklyPay;
    
    public Intern(){
        super();
        WeeklyPay=0.0;
    }
    public Intern(int id,String LastName,double WeeklyPay ){
        super(id,LastName);
        this.WeeklyPay=WeeklyPay;
    }
    public double getWeeklyPay(){
        return this.WeeklyPay=WeeklyPay;
    }
    public void setWeeklyPay(double WeeklyPay){
        this.WeeklyPay=WeeklyPay;
    }
    @Override
    public double ComputeSalary(){
        return WeeklyPay;
    } 
}
