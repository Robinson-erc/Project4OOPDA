
/**
 * Dog
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public class Dog extends Animal
{
    boolean needAWalk;
    boolean hungry;

    public Dog(double weight, String name)
    {
        super(weight, name);
        
        RandomInteger r1 = new RandomInteger(1, 10);
        int num = r1.Generate();
        needAWalk = (num > 8) ? true : false;
        hungry    = (num > 8) ? true : false;
    }

    /**
     * Sound - Concrete implementation
     *
     * @parm - none
     * @return - void
     */
    @Override
    public void Sound()
    {
        System.out.println("Bark!, Bark!! ");
    }
    
    /**
     * Eat - Concrete implementation
     *
     * @param  - none
     * @return - void
     */
    @Override
    public void Eat()
    {
        System.out.println("Eating Purina Pro Plan High Protein Dog Food");
    }
    
    /**
     * Happy - Concrete implementation
     *
     * @param  - none
     * @return - boolean
     */
    @Override
    public boolean Happy()
    {
         return((!needAWalk) && (!hungry));
    }
}
