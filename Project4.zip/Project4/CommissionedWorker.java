
/**
 * Write a description of class CommisionedWorker here.
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public class CommissionedWorker extends Person
{
    private double Sales;
    private double Commision;
    
    public CommissionedWorker(){
        super();
        Sales=0.0;
        Commision=0.0;
    }
    public CommissionedWorker(int id, String LastName, double Sales, double Commision){
        super(id,LastName);
        this.Sales=Sales;
        this.Commision=Commision;
    }
    public double getSales(){
        return this.Sales;
    }
    public double getCommision(){
        return this.Commision;
    }
    public void setSales(double sales){
        this.Sales=sales;
    }
    public void setCommision(double Commision){
        this.Commision=Commision;
    }
    
    @Override
    public double ComputeSalary(){
        return Sales*Commision;
    }
    
}
