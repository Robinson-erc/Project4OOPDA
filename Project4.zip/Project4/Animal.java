
/**
 * Animal Class
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public abstract class Animal
{
    double weight; // lbs
    String name;
    
    Animal(double weight, String name)
    {
        this.weight = weight;
        this.name = name;
    }
    
    /**
     * double getWeight() 
     *
     * @param - none
     * @return double - the weight of the animal in pounds
     */
    public double getWeight()
    {
        return weight;
    }
    
    /**
     * double getName() 
     *
     * @param - none
     * @return String - the animal's name
     */
    public String getName()
    {
        return name;
    }

    
    /**
     * void setWeight(double weight) 
     *
     * @param - double weight
     * @return - none
     */
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    
    
    /**
     * Sound - abstract method
     *
     * @param  - none
     * @return - void
     */
    public abstract void Sound();
    
    /**
     * Eat - abstract method
     *
     * @param  - none
     * @return - void
     */
    public abstract void Eat();
    
    /**
     * Happy - abstract method
     *
     * @param  - none
     * @return - boolean, true - Happy, false - UnHappy
     */
    public abstract boolean Happy();
}
