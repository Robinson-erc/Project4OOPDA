/**
 * Cat
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public class Cat extends Animal
{
    boolean oldToy;

    public Cat(double weight, String name)
    {
        super(weight, name);
        
        RandomInteger r1 = new RandomInteger(1, 10);
        int num = r1.Generate();
        oldToy = (num > 8) ? true : false;
        
    }

    /**
     * Sound - Concrete implementation
     *
     * @parm - none
     * @return - void
     */
    @Override
    public void Sound()
    {
        System.out.println("Meow!, Meow!! ");
    }

    /**
     * Eat - Concrete implementation
     *
     * @param  - none
     * @return - void
     */
    @Override
    public void Eat()
    {
        System.out.println("Eating Friskies Seafood Sensations cat food");
    }

    /**
     * Happy - Concrete implementation
     *
     * @param  - none
     * @return - boolean
     */
    @Override
    public boolean Happy()
    {
        return (!oldToy);
    }
}
