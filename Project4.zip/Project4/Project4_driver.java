
/**
 * Project 5
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
import java.util.List;
import java.util.ArrayList;

public class Project4_driver
{
    public static Animal_Driver Animals;
    public static void main(String[] args)
    {
        System.out.println("Project4, Eric Robinson, student id = 916427599\n");
        
        P1();
        P2();
    }
    
    /**
     * Driver code for Problem1 (The Animal/Pet program)
     *
     */
    
    static void P1()
    {
        // Place Animal driver code here!!
        Animals.Ex1_Pets();
    }
    
    static void P2()
    {
        
        // Do not modify any of the code in this code block!!!
        
        
        List<Person> people = new ArrayList<>();
         
                              //ID    Last Hours  rate
        people.add(new HourlyWorker(101, "Smith", 50, 10.25));
                                    //ID    LAst    Sales    rate
        people.add(new CommissionedWorker(123, "Jones", 10000.0, 0.10));
                        //ID    Last  weekly stipend
        people.add(new Intern(120, "Wilson", 120.00));
        people.add(new HourlyWorker(103, "Williams", 50, 20.25));
        people.add(new CommissionedWorker(140, "Decker", 35000.0, 0.10));
        people.add(new Intern(129, "Brown", 105.00));
        people.add( new HourlyWorker(113, "Miller", 55, 30.25));
        people.add(new CommissionedWorker(150, "Davis", 15000.0, 0.20));
        people.add(new Intern(180, "Adams", 100.00));
        people.add(new HourlyWorker(119, "Murphy", 55, 30.50));
        
        for (int i = 0; i <  people.size(); i++)
        {
            System.out.println(people.get(i)); 
        }

        System.out.println();
        System.out.println("id             Name    Salary");
        for (int i = 0; i <  people.size(); i++)
        {
            System.out.printf("%d %15s  $%8.2f\n",people.get(i).GetId(),people.get(i).GetLastName(), people.get(i).ComputeSalary());
        }
        
        //Performing modifications to the people List
        System.out.println();
        System.out.println("Making modifications to the People List");
        
        Person smith101 = new HourlyWorker(101, "Smith", 50, 10.25);
        boolean foundSmith101 = people.contains(smith101);
        
        if (foundSmith101)
        {
            people.remove(smith101);
            System.out.printf("Removed %d %15s  $%8.2f\n",smith101.GetId(),smith101.GetLastName(), smith101.ComputeSalary());
        }
        
        Person murphy120 = new HourlyWorker(120, "Murphy", 65, 30.50);
        boolean foundMurphy120 = people.contains(murphy120);
        if (!foundMurphy120)
        {
            people.add(murphy120);
            System.out.printf("Adding  %d %15s  $%8.2f\n",murphy120.GetId(),murphy120.GetLastName(), murphy120.ComputeSalary());
        }
        
        
        Person murphy119 = new HourlyWorker(119, "Murphy", 55, 30.50);
        boolean foundMurphy119 = people.contains(murphy120);
        if (foundMurphy119)
        {
            people.remove(murphy119);
            System.out.printf("Removed %d %15s  $%8.2f\n",murphy119.GetId(), murphy119.GetLastName(), murphy119.ComputeSalary());
        }
        
        System.out.println();
        System.out.println("Modifications were made to the people list");
        System.out.println("id             Name    Salary");
        for (int i = 0; i <  people.size(); i++)
        {
            System.out.printf("%d %15s  $%8.2f\n",people.get(i).GetId(),people.get(i).GetLastName(), people.get(i).ComputeSalary());
        }  
        
    }
}