
/**
 * Abstract class Person - write a description of the class here
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
public abstract class Person
{
   private String lastName;
   private int id;
   private static int Amount;
   
   public Person()
   {
       this.lastName=lastName;
       this.id=id;
   }
   public Person(int id, String LastName){
       this.lastName=LastName;
       this.id=id;
       this.Amount++;
   }
   public String GetLastName(){
       return this.lastName;
   }
   public int GetId(){
       return this.id;       
   }
   public void SetLastName(String lastName){
       this.lastName=lastName;
       
   }
   public void SetId(int ID){
       this.id=ID;
   }
   static int HowMany(){
       return Amount;
   }
   @Override
   public String toString(){
       return id+" "+lastName+" "+ComputeSalary();
   }
   @Override
   public boolean equals(Object o){
       Person  obj= (Person)o;     
       return (this.id==obj.id && this.lastName.equals(obj.lastName));
    }
   
   public abstract double ComputeSalary();  
   
   
}
