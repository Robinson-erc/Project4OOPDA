/**
 * Animal Driver for Polymorphism example
 *
 * @author (Eric Robinson)
 * @version (4/12/23)
 */
import java.util.List;
import java.util.ArrayList;

public class Animal_Driver
{
    public static void main()
    {
        Ex1_Pets();
    }
    static void Ex1_Pets()
    {
        List<Animal> pets = new ArrayList<>(); // A List to hold the Animals
        
        pets.add(new Dog(12, "Rover"));    // Create a dog object and store it in array that hold animal objects.
        pets.add(new Cat(7,  "Felix"));    // Create a cat object and store it in array that hold animal objects.
        pets.add(new Cat(6.5,"Garfield")); // Create a cat object and store it in array that hold animal objects.
        pets.add(new Dog(15, "Courage"));  // Create a dog object and store it in array that hold animal objects.
        pets.add(new Dog(14, "Astro"));    // Create a dog object and store it in array that hold animal objects.
        pets.add(new Dragon(1500,"Max")); //Create a dragon object and store it in the array that holds animal objects
        pets.add(new Duck(10,"Sam")); //Create a duck object and store it in the array that hols animal objects.
        //pets[5] = new Turtle(2, "Frank"); // Create a Turtle pet
        
        for (int i = 0; i < pets.size(); i++)
        {
            System.out.println("The pet's name is " + pets.get(i).getName()); // Animal class getter
            System.out.println("It weighs " + pets.get(i).getWeight());       // Animal class getter
            pets.get(i).Sound(); // polymorphic method
            pets.get(i).Eat();   // polymorphic method
            if (pets.get(i).Happy()) // polymorphic method
            {
                System.out.println("The pet is HAPPY");
            }
            else
            {
                System.out.println("The pet is UNHAPPY");
            }
            System.out.println();
        }
        
        
        // Use the Animal getter and setter methods to allow the pets to gain some weight
        for (int i = 0; i < pets.size(); i++)
        {
           double weight = pets.get(i).getWeight();
           weight = weight + 0.5;
           pets.get(i).setWeight(weight);
        }
        
        System.out.println("-----------------------------------------\n");
        System.out.println("After the pets have been eating the great pet food for a month!!!");
        
        for (int i = 0; i < pets.size(); i++)
        {
            System.out.println("The pet's name is " + pets.get(i).getName()); // Animal class getter
            System.out.println("It weighs " + pets.get(i).getWeight());       // Animal class getter
            pets.get(i).Sound(); // polymorphic method
            pets.get(i).Eat();   // polymorphic method
            if (pets.get(i).Happy()) // polymorphic method
            {
                System.out.println("The pet is HAPPY");
            }
            else
            {
                System.out.println("The pet is UNHAPPY");
            }
            System.out.println();
        }
    }
}
